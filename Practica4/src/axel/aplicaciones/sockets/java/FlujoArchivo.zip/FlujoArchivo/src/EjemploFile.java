import java.io.*;
import javax.swing.JFileChooser;
/**
 *
 * @author Axel
 */
public class EjemploFile {
    public static void main(String[] args){
        //public static final String ANSI_YELLOW = "\u001B[33m";
        try{
            JFileChooser jf = new JFileChooser();
            File dir = new File("d:\\Documentos\\IMAGENES\\");
            jf.setCurrentDirectory(dir);
            jf.setRequestFocusEnabled(true);
            jf.requestFocus();
            jf.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
            int r = jf.showDialog(null, "Elegir");
            if(r==JFileChooser.APPROVE_OPTION){
                File f = jf.getSelectedFile();
                String tipo = (f.isDirectory())?"Carpeta":"Archivo";
                System.out.println("\033[32m Elegiste: "+f.getAbsolutePath());
                System.out.println("Tipo: "+tipo);
                if(tipo.compareTo("Archivo")==0){
                    System.out.println("Tamaño:"+f.length()+" bytes");
                    String permisos="";
                    if(f.canRead())
                        permisos = permisos+"r";
                    if(f.canWrite())
                        permisos = permisos+"w";
                    if(f.canExecute())
                        permisos = permisos+"x";
                    System.out.println("Permisos:"+permisos);
                    
                }else if(tipo.compareTo("Carpeta")==0){
                    File[]listado = f.listFiles();
                    System.out.println("Contenido:");
                    for(int x =0;x<listado.length;x++){
                        System.out.println("\033[33m ->"+listado[x]);
                      
                    }//for
                }//else if
            }//if
        }catch(Exception e){
            e.printStackTrace();
        }
    }//main
}
