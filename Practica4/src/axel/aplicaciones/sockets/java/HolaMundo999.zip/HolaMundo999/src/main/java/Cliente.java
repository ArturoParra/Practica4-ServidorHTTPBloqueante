
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;


/**
 *
 * @author Axel
 */
public class Cliente {
    public static void main(String[] args){
        try{
            Socket cl = new Socket("127.0.0.1",1234);
            System.out.print("Conexion con servidor establecida... Escribe tu nombre:");
            BufferedReader br1 = new BufferedReader(new InputStreamReader(System.in));
            PrintWriter pw = new PrintWriter(new OutputStreamWriter(cl.getOutputStream()));
            BufferedReader br = new BufferedReader(new InputStreamReader(cl.getInputStream()));
            String nombre = br1.readLine();
            pw.println(nombre);
            pw.flush();
            System.out.println("Enviando nombre al servidor y esperando saludo..");
            String saludo = br.readLine();
            System.out.println("Mensaje recibido desde el servidor: "+saludo);
            br.close();
            br1.close();
            pw.close();
            cl.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }//main
}
