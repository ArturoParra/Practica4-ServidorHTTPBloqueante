import java.net.*;
import java.io.*;
/**
 *
 * @author Axel
 */
public class Servidor {
 public static void main(String[] args){
     try{
         ServerSocket s = new ServerSocket(1234);
         s.setOption(StandardSocketOptions.SO_REUSEADDR,true);
         System.out.println("Servidor iniciado en el puerto "+s.getLocalPort()+ "con un buffer de "+s.getOption(StandardSocketOptions.SO_RCVBUF));
         for(;;){
             Socket cl = s.accept();
             System.out.println("Cliente conectado desde "+cl.getInetAddress()+":"+cl.getPort());
             System.out.println("Recibiendo informacion del cliente");
             PrintWriter pw = new PrintWriter(new OutputStreamWriter(cl.getOutputStream()));
             BufferedReader br = new BufferedReader(new InputStreamReader(cl.getInputStream()));
             String nombre =br.readLine();
             System.out.println("Enviando saludo a "+nombre);
             pw.println("Hola "+nombre+", recibe un saludo desde un servidor bloqueante..");
             pw.flush();
             pw.close();
             br.close();
             cl.shutdownInput();
             cl.shutdownOutput();
             cl.close();
         }//for
     }catch(Exception e){
         e.printStackTrace();
     }//catch
 }   //main 
}
